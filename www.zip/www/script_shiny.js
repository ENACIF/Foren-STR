// funciones necesarias para el funcionamiento de la app

// al presionar en el pickerInput "Deselect All"  se selecciona el primer elemento en la lista
$(document).on("shiny:inputchanged", function(event) {
  if (event.name === "file") {
    $(document).on("shiny:inputchanged", function(event1) {
      if (event1.name === "cols_sel" || event1.name === "num_pops") {
        var buttons = document.getElementsByClassName("bs-deselect-all");
        Array.from(buttons).forEach(function(button, index) {
          button.addEventListener("click", function(event) {
            event.stopImmediatePropagation();
            event.preventDefault();
            Shiny.setInputValue('deselect', { input_id: event1.name, value: 1 }, { priority: "event" });
          });
        });
      }
    });
  }
  // se evita que se desmarque el único elemento seleccionado
  $("#cols_sel").on("show.bs.select", function(){
    $("a[role=option]").on("click", function(e){
      var selections = $("#cols_sel").val();
      if(selections.length === 1 && $(this).hasClass("selected")){
        e.stopImmediatePropagation();
      };
    });
  }).on("hide.bs.select", function(){
    $("a[role=option]").off("click");
  });
  // este código recarga la página si se requiere introducir un nuevo archivo
  var file_clicked = 0;
  $(document).ready(function() {
    $("#file").on("click", function() {
       Shiny.setInputValue('file_clicked', file_clicked+1);
       file_clicked = file_clicked + 1;
     });
  });
  // aplicar formato de decimales a datatables
  $('[id^=table_estall]').on('draw.dt', function() {
    $(this).find('td:nth-child(2)').each(function() {
      var value = $(this).text();
      var formattedValue = formatValue(value);
      $(this).text(formattedValue);
    });
  });

});

// formato de notación científica y flotantes
function formatValue(value) {
  const numValue = Number(value);
  if (isNaN(numValue)) {
    return '-'; 
  }
  if (Math.abs(numValue) < 0.0001 || Math.abs(numValue) > 1e5) {
    return numValue.toExponential(4);
  } else {
    return numValue.toFixed(4); 
  }
}

//traducir elementos de datatable (headers y botones)
$(document).ready(function() {
  
  function actualizarTexto(lang) {
    const ms = [1500, 9000, 20000];
    
    const traducciones = {
      'Allele': 'Alelo',
      'Population': 'Población',
      'SPFI': 'PEIF',
      'Genotype': 'Genotipo',
      'Combined value': 'Valor combinado',
      'Copy': 'Copiar',
      'Download TXT': 'Descargar TXT',
      'Nothing selected': 'Nada seleccionado',
      'Select All': 'Seleccionar Todo',
      'Deselect All': 'Deseleccionar Todo',
    };

    function traducir() {
       

      $('.tablashiny:visible thead th[tabindex], .btn').each(function() {
        let texto = $(this).text().trim();
        if (lang === 'es' && traducciones[texto]) {
          $(this).text(traducciones[texto]); // Traducir a español
        } else if (lang === 'en') {
          let claveOriginal = Object.keys(traducciones).find(key => traducciones[key] === texto);
          if (claveOriginal) {
            $(this).text(claveOriginal); // Regresar a inglés
          }
        }
      });
    }
    ms.forEach((ms) => {
      setTimeout(traducir, ms);
    });
  }

  Shiny.addCustomMessageHandler('idioma_cambiado', function(lang) {
    requestAnimationFrame(() => {
      actualizarTexto(lang);
    });

    actualizarTexto(lang);
    $('.tablashiny').on('draw.dt', function() {
     requestAnimationFrame(() => {
        actualizarTexto(lang);
      });    
    });
  });
});

// traducir botones select y deselect
$(document).on('mousedown', 'button[data-toggle="dropdown"]', function() {
  $('.bs-select-all, .bs-deselect-all').each(function() {
    let texto = $(this).text().trim();
    if (lang === 'es' && traducciones[texto]) {
      $(this).text(traducciones[texto]);
    } else if (lang === 'en') {
      let claveOriginal = Object.keys(traducciones).find(key => traducciones[key] === texto);
      if (claveOriginal) {
        $(this).text(claveOriginal);
      }
    }
  });
});

//descargar txt en lugar de csv
function exportToTxt(e, dt, button, config) {
  var data = dt.buttons.exportData();

  var txtData = data.header.join('\t') + '\n';
  for (var i = 0; i < data.body.length; i++) 
    txtData += data.body[i].join('\t') + '\n';
    
  var blob = new Blob([txtData], {type: 'text/plain;charset=utf-8'});
  var link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'datatable.txt';
  link.click();
}
Shiny.addCustomMessageHandler("exportToTxt", function(message) {
  exportToTxt();
});